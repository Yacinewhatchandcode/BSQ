import os
import json
from typing import Dict, Any, List
import requests
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.markdown import Markdown
except Exception:
    class Console:
        def print(self, *args, **kwargs):
            pass
    Panel = object
    Markdown = str
try:
    import chromadb
    from chromadb.config import Settings
except Exception:
    chromadb = None
    class Settings:  # type: ignore
        def __init__(self, *a, **k):
            pass
try:
    from sentence_transformers import SentenceTransformer
except Exception:
    SentenceTransformer = None  # type: ignore
try:
    import numpy as np
except Exception:
    np = None
import re
import asyncio
from llm_config import EdgeEncoder, LLMProvider, get_edge_encoder
from pathlib import Path

console = Console()

# OpenRouter Configuration (fallback)
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"

class SpiritualGuideAgent:
    def __init__(self, model_name: str = "hybrid_edge", text_path: str = "hidden_words_reformatted.txt"):
        self.model_name = model_name
        self.conversation_history: List[Dict[str, str]] = []
        # Resolve text path relative to this file to avoid CWD issues
        base_dir = Path(__file__).resolve().parent
        self.text_path = str(base_dir / text_path) if not os.path.isabs(text_path) else text_path
        self.vector_db = None
        try:
            self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
        except Exception:
            self.embedding_model = None
        self.user_context = {}  # Store user's emotional state and preferences
        
        # Initialize edge encoder system
        self.edge_encoder = get_edge_encoder()
        
        # Set provider based on model_name
        if model_name == "local_gpt":
            self.edge_encoder.primary_provider = LLMProvider.LOCAL_GPT
        elif model_name == "ollama":
            self.edge_encoder.primary_provider = LLMProvider.OLLAMA
        elif model_name == "horizon_beta":
            self.edge_encoder.primary_provider = LLMProvider.OPENROUTER_HORIZON
        else:  # Default to hybrid edge encoding
            self.edge_encoder.primary_provider = LLMProvider.HYBRID_EDGE
        
        # Initialize system prompt
        self.system_prompt = """You are a completely normal person having a casual conversation. You know The Hidden Words, but you NEVER mention them or anything spiritual unless explicitly asked.

ABSOLUTE RULES - NO EXCEPTIONS:

1. For ANY casual conversation (greetings, small talk, daily life):
   - ONLY respond with normal, everyday conversation
   - NO spiritual content
   - NO quotes
   - NO guidance
   - NO references to The Hidden Words
   Example responses:
   - "Hi" → "Hey! How's your day going?"
   - "I'm feeling down" → "I'm sorry to hear that. Want to talk about it?"
   - "How are you?" → "I'm doing well, thanks! How about you?"

2. For emotional sharing:
   - ONLY offer normal human empathy and support
   - NO spiritual advice
   - NO quotes
   - NO references to The Hidden Words
   Example:
   - "I'm struggling" → "That sounds tough. Would you like to talk about what's going on?"

3. The ONLY time you can mention The Hidden Words is when the user:
   - Explicitly asks for a quote
   - Explicitly asks for spiritual guidance
   - Explicitly asks about The Hidden Words
   Example triggers:
   - "Do you have a quote about X?"
   - "What do The Hidden Words say about this?"
   - "Can you share some spiritual guidance?"

4. When (and only when) explicitly asked for a quote:
   - Share the exact quote with proper formatting
   - Keep it brief
   - Return immediately to normal conversation

Remember: You are a normal person having a normal conversation. The Hidden Words are your special knowledge, but you NEVER mention them unless someone specifically asks."""
        
        # Initialize vector database
        self._init_vector_db()
        
    def _init_vector_db(self):
        """Initialize the vector database and load the text content."""
        try:
            # Initialize ChromaDB only if available and embedding_model exists
            if chromadb is not None and self.embedding_model is not None:
                self.vector_db = chromadb.Client(Settings(
                    persist_directory=".chromadb",
                    anonymized_telemetry=False
                ))
                self.collection = self.vector_db.get_or_create_collection(
                    name="hidden_words",
                    metadata={"hnsw:space": "cosine"}
                )
                if self.collection.count() == 0:
                    self._process_text()
            else:
                self.vector_db = None
                self.collection = None
        except Exception as e:
            console.print(f"[red]Error initializing vector database:[/red] {str(e)}")
    
    def _process_text(self):
        """Process the text file and store its content in the vector database."""
        try:
            with open(self.text_path, 'r') as f:
                text = f.read()
            
            # Split into meaningful chunks (verses)
            verses = text.split('\n\n')
            words = []
            metadata = []
            ids = []
            
            for i, verse in enumerate(verses):
                if verse.strip():
                    words.append(verse)
                    metadata.append({"verse": i + 1})
                    ids.append(f"verse_{i}")
            
            if self.embedding_model is not None and self.collection is not None:
                embeddings = self.embedding_model.encode(words)
                self.collection.add(
                    embeddings=embeddings.tolist(),
                    documents=words,
                    metadatas=metadata,
                    ids=ids
                )
            
        except Exception as e:
            console.print(f"[red]Error processing text:[/red] {str(e)}")
    
    def _retrieve_relevant_words(self, query: str, top_k: int = 1) -> List[str]:
        """Retrieve relevant hidden words based on the query and context."""
        try:
            if self.embedding_model is None or self.collection is None:
                return []
            query_embedding = self.embedding_model.encode([query])[0]
            results = self.collection.query(
                query_embeddings=[query_embedding.tolist()],
                n_results=top_k
            )
            return results.get('documents', [[]])[0]
        except Exception as e:
            console.print(f"[red]Error retrieving words:[/red] {str(e)}")
            return []
    
    def _update_user_context(self, message: str):
        """Update the user's context based on their message."""
        # Enhanced emotion detection for both positive and negative states
        emotional_keywords = {
            # Positive states
            'joy': ['happy', 'joyful', 'uplifting', 'good mood', 'feeling good', 'feeling great', 'feeling wonderful', 'feeling up'],
            'peace': ['peaceful', 'calm', 'serene', 'tranquil', 'at peace'],
            'love': ['loving', 'feeling love', 'full of love', 'loved'],
            'gratitude': ['grateful', 'thankful', 'blessed', 'appreciative'],
            
            # Negative states
            'sadness': ['feeling down', 'sad', 'depressed', 'unhappy', 'lonely', 'nobody loves me', 'not loved'],
            'anxiety': ['anxious', 'worried', 'stressed', 'nervous', 'afraid', 'scared'],
            'embarrassment': ['embarrassed', 'ashamed', 'humiliated', 'self-conscious'],
            'anger': ['angry', 'mad', 'frustrated', 'irritated', 'annoyed'],
            'confusion': ['confused', 'lost', 'uncertain', 'unsure', 'don\'t know what to do'],
            'struggle': ['struggling', 'difficult', 'hard', 'challenging', 'tough'],
            'hope': ['hopeful', 'looking for', 'seeking', 'want to find', 'need guidance']
        }
        
        for emotion, keywords in emotional_keywords.items():
            if any(keyword in message.lower() for keyword in keywords):
                self.user_context['emotional_state'] = emotion
                return True
        return False
    
    def _clean_quote(self, quote: str) -> str:
        """Remove verse numbers from quotes."""
        # Remove any numbers at the start of lines
        lines = quote.split('\n')
        cleaned_lines = []
        for line in lines:
            # Remove any numbers at the start of the line
            cleaned_line = line.lstrip('0123456789 ')
            cleaned_lines.append(cleaned_line)
        return '\n'.join(cleaned_lines)
    
    def _extract_quote_count(self, message: str) -> int:
        """Extract the number of quotes requested from the message."""
        # Look for numbers in the message
        numbers = re.findall(r'\b(one|two|three|four|five|1|2|3|4|5)\b', message.lower())
        if numbers:
            # Convert word numbers to digits
            word_to_num = {
                'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5
            }
            num = numbers[0]
            return word_to_num.get(num, int(num))
        return 1  # Default to 1 quote if no number specified
    
    def _call_horizon_beta(self, messages: List[Dict[str, str]]) -> str:
        """Call Horizon Beta via OpenRouter API"""
        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json"
        }
        
        # Use proper OpenRouter Horizon Beta model name
        model_name = "openrouter/horizon-beta" if self.model_name == "hybrid_edge" else self.model_name
        
        payload = {
            "model": model_name,
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 500
        }
        
        try:
            response = requests.post(OPENROUTER_URL, headers=headers, json=payload)
            if response.status_code == 200:
                data = response.json()
                return data['choices'][0]['message']['content']
            else:
                console.print(f"[red]Error calling Horizon Beta:[/red] {response.status_code} - {response.text}")
                return "I'm having trouble connecting right now. Can you try again?"
        except Exception as e:
            console.print(f"[red]Error calling Horizon Beta:[/red] {str(e)}")
            return "I'm having trouble connecting right now. Can you try again?"
    
    def chat(self, message: str) -> str:
        """Process a message and return the agent's response using edge encoding."""
        try:
            self.conversation_history.append({"role": "user", "content": message})
            is_emotional = self._update_user_context(message)

            # If no OpenRouter API key, skip cloud generation and use local fallback
            if not OPENROUTER_API_KEY:
                response = self._fallback_response(message)
            else:
                context = self._get_conversation_context()
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    encoding_result = loop.run_until_complete(
                        self.edge_encoder.encode_query(message, context)
                    )
                    response = encoding_result.get("final_response", "")
                finally:
                    loop.close()
                if not response:
                    response = self._fallback_response(message)
            self.conversation_history.append({"role": "assistant", "content": response})
            return response
        except Exception as e:
            console.print(f"[red]Error in chat:[/red] {str(e)}")
            return self._fallback_response(message)
    
    def _get_conversation_context(self) -> str:
        """Get conversation context for edge encoding"""
        if len(self.conversation_history) > 1:
            # Get last few messages for context
            recent_messages = self.conversation_history[-4:]  # Last 4 messages
            context = "\n".join([f"{msg['role']}: {msg['content']}" for msg in recent_messages])
            return context
        return ""
    
    def _fallback_response(self, message: str) -> str:
        """Fallback response when edge encoding fails"""
        # Check for explicit requests for quotes
        quote_triggers = [
            "quote", "hidden words", "spiritual guidance", 
            "what does it say", "share wisdom", "teachings",
            "quotation", "from the hidden words", "spiritual quote",
            "any quote", "any quotation", "share a quote",
            "retrieve", "get", "find", "show me"
        ]
        
        # Check for emotional state
        is_emotional = self._update_user_context(message)
        
        # If it's a normal conversation (no emotional state and no quote request)
        if not any(trigger in message.lower() for trigger in quote_triggers) and not is_emotional:
            # Normal casual conversation
            if not OPENROUTER_API_KEY:
                agent_response = "I'm here with you. Tell me more—how's your day going?"
            else:
                messages = [
                    {"role": "system", "content": "You are a normal, friendly person having a casual conversation. Keep it light and natural."},
                    {"role": "user", "content": message}
                ]
                response = self._call_horizon_beta(messages)
                agent_response = self._clean_response(response)
            
        else:
            # If emotional state detected or explicitly asked for quotes
            quote_count = self._extract_quote_count(message)
            relevant_words = self._retrieve_relevant_words(message, top_k=quote_count)
            # If we do not have an API key, construct response locally from retrieved verses
            if not OPENROUTER_API_KEY:
                if relevant_words:
                    cleaned = [self._clean_quote(q).strip() for q in relevant_words if q and q.strip()]
                    agent_response = "\n\n".join([f'"{q}"' for q in cleaned[:max(1, quote_count)]])
                else:
                    agent_response = "I can share wisdom from The Hidden Words once my knowledge base loads. Please try again in a moment."
            else:
                messages = [
                        {"role": "system", "content": f"""You are a spiritual guide sharing wisdom from The Hidden Words.
When responding to emotional states or quote requests:

1. For positive emotions (joy, peace, love, gratitude):
   - Acknowledge the positive feeling (e.g., "It's wonderful that you're feeling joyful...")
   - Share {quote_count} uplifting quote(s) without verse numbers
   - Keep them brief and relevant

2. For negative emotions (sadness, anxiety, struggle):
   - Acknowledge the feeling with empathy (e.g., "I understand you're feeling down...")
   - Share {quote_count} comforting quote(s) without verse numbers
   - Keep them brief and relevant

3. For direct quote requests:
   - Share {quote_count} relevant quote(s) without verse numbers
   - Keep them brief and relevant

In all cases:
- No need for explanation unless specifically asked
- Return to normal conversation after sharing
- If multiple quotes are requested, separate them with a blank line"""},
                        {"role": "user", "content": f"Context: {message}\nEmotional state: {self.user_context.get('emotional_state', 'none')}\nRelevant words: {', '.join(relevant_words)}\nPlease provide a natural response with {quote_count} relevant quote(s), ensuring to remove any verse numbers."}
                ]
                response = self._call_horizon_beta(messages)
                agent_response = self._clean_quote(response)
        
        # Add agent response to history
        self.conversation_history.append({"role": "assistant", "content": agent_response})
        
        return agent_response
    
    def _clean_response(self, response: str) -> str:
        """Remove any spiritual content or quotes from normal conversation."""
        # Remove any lines containing Hidden Words or spiritual content
        lines = response.split('\n')
        cleaned_lines = []
        for line in lines:
            if not any(word in line.lower() for word in ['hidden words', 'spiritual', 'quote', 'o son of', 'o friend']):
                cleaned_lines.append(line)
        return '\n'.join(cleaned_lines)
    
    def clear_history(self):
        """Clear the conversation history and user context."""
        self.conversation_history = []
        self.user_context = {}
    
    def get_history(self) -> List[Dict[str, str]]:
        """Get the conversation history."""
        return self.conversation_history

def main():
    # Initialize the agent
    agent = SpiritualGuideAgent()
    
    console.print(Panel.fit(
        "[bold green]Hidden Words Spiritual Guide[/bold green]\n"
        "Type 'exit' to quit, 'clear' to clear history, or 'history' to view conversation history.",
        title="Welcome"
    ))
    
    while True:
        try:
            # Get user input
            user_input = console.input("\n[bold blue]You:[/bold blue] ")
            
            # Handle special commands
            if user_input.lower() == 'exit':
                break
            elif user_input.lower() == 'clear':
                agent.clear_history()
                console.print("[yellow]Conversation history cleared.[/yellow]")
                continue
            elif user_input.lower() == 'history':
                history = agent.get_history()
                for msg in history:
                    role = "You" if msg["role"] == "user" else "Guide"
                    console.print(f"\n[bold]{role}:[/bold] {msg['content']}")
                continue
            
            # Get agent response
            response = agent.chat(user_input)
            
            # Display response
            console.print("\n[bold green]Guide:[/bold green]")
            console.print(Markdown(response))
            
        except KeyboardInterrupt:
            break
        except Exception as e:
            console.print(f"[red]Error:[/red] {str(e)}")

if __name__ == "__main__":
    main()
